﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnalloPRoject.Model
{
    class Onallo
    {
        private int _akarszam;
        private int _dobas;

        public Onallo()
        {
            _akarszam = 0;
            _dobas = 0;
        }

        public int Akarszam
        {
            get => _akarszam;
            set => _akarszam = value;
        }

        public int Dobas
        {
            get => _dobas;
            set => _dobas = value;
        }

        public double LegalabbEgy
        {
            get
            {
                return 1 - Math.Pow((1 - _akarszam), (_dobas));
                //(1- (1-p)^n valoszinuseggel bekovetkezik legalabb 1-szer
            }
        }

        public double PontosanEgy
        {
            get
            {
                return _dobas * _akarszam * Math.Pow((1 - _akarszam), (_dobas - 1));
                //n* p* (1-p)^(n-1) valoszinuseggel bekovetkezik pontosan 1-szer
            }
        }

    }
}
