﻿using OnalloPRoject.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.BaseClass;

namespace OnalloPRoject.ViewModel
{
    public class OnalloViewModel : ViewModelBase
    {
        private Onallo _dob;

        public OnalloViewModel()
        {
            _dob = new Onallo();
            CalculationCommand = new RelayCommand(execute => Calculation());
        }

        public RelayCommand CalculationCommand { get; private set; }

        public string Akarszam
        {
            get
            {
                return _dob.Akarszam.ToString();
            }
            set
            {
                try
                {
                    int akar = Convert.ToInt32(value);
                    _dob.Akarszam = akar;
                }
                catch(Exception e)
                {
                }
            }
        }

        public string Dobas
        {
            get
            {
                return _dob.Dobas.ToString();
            }
            set
            {
                try
                {
                    int dobas = Convert.ToInt32(value);
                    _dob.Dobas = dobas;
                }
                catch(Exception e)
                {
                }
            }
        }

        public string Legalabb
        {
            get
            {
                double roundedLegalabb = _dob.LegalabbEgy;
                return "Ennyi a valószínűsége, hogy legalább egyszer bekövetkezik: " + roundedLegalabb;
            }
        }

        public string Pontosan
        {
            get
            {
                double roundedPontos = _dob.PontosanEgy;
                return "Ennyi a valőszínűsége, hogy pontosan egyszer bekövetkezik: " + roundedPontos;
            }
        }

        private void Calculation()
        {
            OnPropertyChanged(nameof(Legalabb));
            OnPropertyChanged(nameof(Pontosan));
        }
    }
}
