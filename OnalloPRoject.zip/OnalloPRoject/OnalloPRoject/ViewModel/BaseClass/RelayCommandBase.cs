﻿namespace ViewModels.BaseClass
{
    public abstract class RelayCommandBase
    {
        public abstract bool CanExecute(object parameter);
    }
}